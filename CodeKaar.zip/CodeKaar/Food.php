<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Navbar using animated Topmost world website</title>
<link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="animate.css">
<script type="text/javascript" src="jquery-3.2.1.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$("#mymenu").click(function(){
			$("#my-bs").addClass("animated zoomInUp");
			if($("#my-bs").hasClass("pop-menu"))
			{
				$("#my-bs").removeClass("pop-menu").hide();
			}
			else
			{
				$("#my-bs").addClass("pop-menu").show();
			}

		});
	});
</script>
<style type="text/css">
    .btn-default
    {
      padding: 6px 24px;
      border: 2px solid #ccc;
    }
		.navbar-default .navbar-nav > li > a
		{
			color: #190d0d;
		}
		.fa-search
		{
			text-decoration: none;
			cursor: pointer;
		}
		.navbar-default
		{
			background:#fff;
			box-shadow: 1px 1px 18px rgba(0,0,0,0.43);
		}
		.navbar-collapse
		{
			max-height:475px;
		}
		/*.navbar-nav > li > a
		{
			line-height: 29px;
		}*/
		.carousel-indicators li 
		{
		  display: inline-block;
		  width: 20px;
		  height: 20px;
		  margin: 1px;
		  text-indent: -999px;
		  cursor: pointer;
		  background-color: #000 \9;
		  background-color: rgba(0, 0, 0, 0);
		  border: 4px solid #fff;
		  border-radius: 10px;
		}
		.carousel-indicators .active
		{
		  width: 20px;
		  height: 20px;
		  margin: 0;
		  background-color: #fff;
		}
		#p,#q
		{
			color:#fff;
			font-size:22px;
		}
		.p
		{
			text-align:center;
			color:#fff;
			text-indent:-35px;
			font-size:25px;
		}
		.carousel-caption 
		{
  			position: absolute;
  			right: 15%;
  			bottom: 80px;
  			left: 15%;
  			z-index: 10;
  			padding-top: 20px;
  			padding-bottom: 20px;
  			color: #fff;
  			text-align: center;
  			text-shadow: 0 1px 2px rgba(0, 0, 0, .6);
		}
		.navbar-default
		{
			opacity: 0.9;
		}
		@media screen and (max-width:320px)
		{
			.navbar-default
			{
				box-shadow: none;
				padding: 10px 0px;
			}
			.navbar-default .navbar-collapse
			{
				background: #fff;
				margin: 5px 0px 0px 10px;box-shadow: 1px 1px 18px rgba(0,0,0,0.43);
			}
			.container > .navbar-header, .container-fluid > .navbar-header, .container > .navbar-collapse, .container-fluid > .navbar-collapse
			{
				box-shadow: 1px 1px 18px rgba(0,0,0,0.43);
				background: #fff;
				padding: 6px 40px;
				border:none;
			}
			.pop-menu form input[type="text"]
			{
				width:60%;float: left;
			}
			.pop-menu form button
			{
				margin-top:-5px;
			}
			.btn
			{
			        margin-top:-5px;
			}
		} 
</style>
</head>
<body>

<section class="home">
	<div class="row">
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" aria-expanded="true" id="mymenu">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#" style="color: #190d0d;">Food Delivery</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="my-bs">
      <ul class="nav navbar-nav">
        <li class="active-black"><a href="#home">HOME <span class="sr-only">(current)</span></a></li>
        <li><a href="#about">FOOD MENU</a></li>
      
            <li><a href="#contact">CONTACT US</a></li>
            <li><a href="">TRACK ORDER</a></li>
            <!--<li class="dropdown">
            	<a href="count.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">RECHARGE<span class="caret"></span></a>
            	<ul class="dropdown-menu">
            		<li><a href="count.html">PC1</a></li>
            		<li><a href="count.html">PC2</a></li>
            		<li><a href="count.html">PC3</a></li>
            		<li><a href="count">PC4</a></li>
            	</ul>
            </li>-->
            <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">MY ACCOUNT
            	<span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
            	<li><a href="#">Settings</a></li>
            	<li><a href="#">Profile</a></li>
            	<li class="divider"></li>
            	<li><a href="#">Log out</a></li>
            </ul>
        </li>
          </ul>
      <form>
        <div class="col-md-3">
          <div class="input-group" style="margin-top: 8px;">
          	<input type="search" size="10" name="search" class="form-control" placeholder="You are hungry ....!!!!">
          <span class="input-group-addon"><a class="fa fa-search"></a></span>
          </div>
        </div>
    </form>
        <ul class="nav navbar-nav navbar-right">
        <li><a href="Login.html"><i class="fa fa-sign-in" aria-hidden="true"></i>  SIGN IN</a></li>
        <li><a href="re1.html"><i class="fa fa-sign-out" aria-hidden="true"></i>  SIGN UP</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>


	 <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
       <li data-target="#myCarousel" data-slide-to="3"></li>
        <li data-target="#myCarousel" data-slide-to="4"></li>
         <li data-target="#myCarousel" data-slide-to="5"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="Los Angeles" style="width:100%;">
        <div class="carousel-caption">
          <h3>Los Angeles</h3>
          <p>LA is always so much fun!</p>
        </div>
      </div>

      <div class="item">
        <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="Chicago" style="width:100%;">
        <div class="carousel-caption">
          <h3>Chicago</h3>
          <p>Thank you, Chicago!</p>
        </div>
      </div>
    
      <div class="item">
        <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" style="width:100%;">
        <div class="carousel-caption">
          <h3>New York</h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>
  		
      <div class="item">
        <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" style="width:100%;">
        <div class="carousel-caption">
          <h3>New York</h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>

      <div class="item">
        <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" style="width:100%;">
        <div class="carousel-caption">
          <h3>New York</h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>

      <div class="item">
        <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" style="width:100%;">
        <div class="carousel-caption">
          <h3>New York</h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>

    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="fa fa-arrow_left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="fa fa-arrow_right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

</section>

<section id="about">
	
      
      <center><h3>FOOD MENU</h3></center>
      <br>
      <div class="col-md-12 container">
        <div class="col-md-3">
          <div class="panel panel-default">
            <div class="panel-body">
              <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" class="img-responsive">
              <h4 class="panel-heading text-center">Pizza</h4>
              <div class="col-md-12">
                <div class="col-md-6">
                  <span style="line-height: 35px;">Rs.350</span>
                </div>
                <div class="col-md-6">
                  <button class="btn btn-default">Order Now</button>
                </div>
              </div>
            
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="panel panel-default">
            <div class="panel-body">
              <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" class="img-responsive">
              <h4 class="panel-heading text-center">Pizza</h4>
              <div class="col-md-12">
                <div class="col-md-6">
                  <span style="line-height: 35px;">Rs.350</span>
                </div>
                <div class="col-md-6">
                  <button class="btn btn-default">Order Now</button>
                </div>
              </div>
              
            </div>
          </div>
        </div>


        <div class="col-md-3">
          <div class="panel panel-default">
            <div class="panel-body">
              <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" class="img-responsive">
              <h4 class="panel-heading text-center">Coffee</h4>
              <div class="col-md-12">
                <div class="col-md-6">
                  <span style="line-height: 35px;">Rs.350</span>
                </div>
                <div class="col-md-6">
                  <button class="btn btn-default">Order Now</button>
                </div>
              </div>
             
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="panel panel-default">
            <div class="panel-body">
              <img src="https://images-prod.healthline.com/hlcmsresource/images/AN_images/50-super-healthy-foods-1296x728-feature.jpg" alt="New York" class="img-responsive">
              <h4 class="panel-heading text-center">Burger</h4>
              <div class="col-md-12">
                <div class="col-md-6">
                  <span style="line-height: 35px;">Rs.350</span>
                </div>
                <div class="col-md-6">
                  <button class="btn btn-default">Order Now</button>
                </div>
              </div>
             
            </div>
          </div>
        </div>
      </div>
  
  
</section>

<section id="contact">
  <br><br>
  <?php
  $con=pg_connect("host=localhost dbname=postgres user=sunil password=password") or die(pg_error());
  if($con!=null)
  {
    echo "connection_status";
  }
  else
  {
    echo "connection_aborted()";
  }

// Show all information, defaults to INFO_ALL
phpinfo();

// Show just the module information.
// phpinfo(8) yields identical results.
phpinfo(INFO_MODULES);
  ?>
</section>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>